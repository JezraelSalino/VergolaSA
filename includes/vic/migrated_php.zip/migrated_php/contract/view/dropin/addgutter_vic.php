<?php
if ($getQty[4] != '0.00' && $getQty[5] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: table-row;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: table-row;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display: none;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
} 

elseif ($getQty[4] != '0.00' && $getQty[5] != '0.00' && $getQty[6] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: table-row;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: table-row;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display: none;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
} 
elseif ($getQty[4] != '0.00' && $getQty[5] != '0.00' && $getQty[6] != '0.00' && $getQty[7] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: table-row;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: table-row;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display: none;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}
elseif ($getQty[4] != '0.00' && $getQty[5] != '0.00' && $getQty[6] != '0.00' && $getQty[7] != '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: table-row;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display: none;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}
elseif ($getQty[8] != '0.00' && $getQty[9] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: table-row;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}
elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: table-row;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}

elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] != '0.00' && $getQty[11] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: table-row;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}

elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] != '0.00' && $getQty[11] != '0.00' && $getQty[12] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: table-row;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}


elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] != '0.00' && $getQty[11] != '0.00' && $getQty[12] != '0.00' && $getQty[13] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: table-row;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}

elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] != '0.00' && $getQty[11] != '0.00' && $getQty[12] != '0.00' && $getQty[13] != '0.00' && $getQty[14] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: table-row;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}

elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] != '0.00' && $getQty[11] != '0.00' && $getQty[12] != '0.00' && $getQty[13] != '0.00' && $getQty[14] != '0.00' && $getQty[15] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: table-row;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}

elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] != '0.00' && $getQty[11] != '0.00' && $getQty[12] != '0.00' && $getQty[13] != '0.00' && $getQty[14] != '0.00' && $getQty[15] != '0.00' && $getQty[16] == '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: table-row;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}

elseif ($getQty[8] != '0.00' && $getQty[9] != '0.00' && $getQty[10] != '0.00' && $getQty[11] != '0.00' && $getQty[12] != '0.00' && $getQty[13] != '0.00' && $getQty[14] != '0.00' && $getQty[15] != '0.00' && $getQty[16] != '0.00'){
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: none;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: none;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display:table-row;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";	
}

else {
// Add New Standard Gutter 1
echo "<tr id=\"stdgutter10\" style=\"display: table-row;\"><td><input id=\"addgutter1\" onClick=\"showgutter1();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 2
echo "<tr id=\"stdgutter11\" style=\"display: none;\"><td><input id=\"addgutter2\" onClick=\"showgutter2();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 3
echo "<tr id=\"stdgutter12\" style=\"display: none;\"><td><input id=\"addgutter3\" onClick=\"showgutter3();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 4
echo "<tr id=\"stdgutter13\" style=\"display: none;\"><td><input id=\"addgutter4\" onClick=\"showgutter4();\" type=\"button\" value=\"Add New Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 1
echo "<tr id=\"nonstdgutter10\" style=\"display: table-row;\"><td><input id=\"addnonstd1\" onClick=\"shownonstd1();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 2
echo "<tr id=\"nonstdgutter11\" style=\"display: none;\"><td><input id=\"addnonstd2\" onClick=\"shownonstd2();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 3
echo "<tr id=\"nonstdgutter12\" style=\"display: none;\"><td><input id=\"addnonstd3\" onClick=\"shownonstd3();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 4
echo "<tr id=\"nonstdgutter13\" style=\"display: none;\"><td><input id=\"addnonstd4\" onClick=\"shownonstd4();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 5
echo "<tr id=\"nonstdgutter14\" style=\"display: none;\"><td><input id=\"addnonstd5\" onClick=\"shownonstd5();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 6
echo "<tr id=\"nonstdgutter15\" style=\"display: none;\"><td><input id=\"addnonstd6\" onClick=\"shownonstd6();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 7
echo "<tr id=\"nonstdgutter16\" style=\"display: none;\"><td><input id=\"addnonstd7\" onClick=\"shownonstd7();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 8
echo "<tr id=\"nonstdgutter17\" style=\"display: none;\"><td><input id=\"addnonstd8\" onClick=\"shownonstd8();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Non Standard Gutter 9
echo "<tr id=\"nonstdgutter18\" style=\"display: none;\"><td><input id=\"addnonstd9\" onClick=\"shownonstd9();\" type=\"button\" value=\"Add Non-Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add New Standard Gutter 0
echo "<tr id=\"stdgutter9\" style=\"display: none;\"><td><input id=\"addgutter0\" onClick=\"showgutter0();\" type=\"button\" value=\"Add Standard Gutter\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
}
?>