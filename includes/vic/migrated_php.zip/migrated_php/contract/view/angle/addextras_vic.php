<?php
if ($getQty[55] != '0.00' && $getQty[56] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: table-row;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: table-row;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: table-row;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] != '0.00' && $getQty[59] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: table-row;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] != '0.00' && $getQty[59] != '0.00' && $getQty[60] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: table-row;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] != '0.00' && $getQty[59] != '0.00' && $getQty[60] != '0.00' && $getQty[61] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: table-row;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] != '0.00' && $getQty[59] != '0.00' && $getQty[60] != '0.00' && $getQty[61] != '0.00'&& $getQty[62] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: table-row;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] != '0.00' && $getQty[59] != '0.00' && $getQty[60] != '0.00' && $getQty[61] != '0.00'&& $getQty[62] != '0.00' && $getQty[63] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: table-row;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] != '0.00' && $getQty[59] != '0.00' && $getQty[60] != '0.00' && $getQty[61] != '0.00'&& $getQty[62] != '0.00' && $getQty[63] != '0.00' && $getQty[64] == '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: table-row;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

elseif ($getQty[55] != '0.00' && $getQty[56] != '0.00' && $getQty[57] != '0.00' && $getQty[58] != '0.00' && $getQty[59] != '0.00' && $getQty[60] != '0.00' && $getQty[61] != '0.00'&& $getQty[62] != '0.00' && $getQty[63] != '0.00' && $getQty[64] != '0.00'){
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: none;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }

else{
// Add Extras 1
echo "<tr id=\"extra12\" style=\"display: none;\"><td><input id=\"addextra1\" onClick=\"showextra1();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 2
echo "<tr id=\"extra13\" style=\"display: table-row;\"><td><input id=\"addextra2\" onClick=\"showextra2();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 3
echo "<tr id=\"extra14\" style=\"display: none;\"><td><input id=\"addextra3\" onClick=\"showextra3();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 4
echo "<tr id=\"extra15\" style=\"display: none;\"><td><input id=\"addextra4\" onClick=\"showextra4();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 5
echo "<tr id=\"extra16\" style=\"display: none;\"><td><input id=\"addextra5\" onClick=\"showextra5();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 6
echo "<tr id=\"extra17\" style=\"display: none;\"><td><input id=\"addextra6\" onClick=\"showextra6();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 7
echo "<tr id=\"extra18\" style=\"display: none;\"><td><input id=\"addextra7\" onClick=\"showextra7();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 8
echo "<tr id=\"extra19\" style=\"display: none;\"><td><input id=\"addextra8\" onClick=\"showextra8();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 9
echo "<tr id=\"extra20\" style=\"display: none;\"><td><input id=\"addextra9\" onClick=\"showextra9();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 10
echo "<tr id=\"extra21\" style=\"display: none;\"><td><input id=\"addextra10\" onClick=\"showextra10();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";

// Add Extras 11
echo "<tr id=\"extra22\" style=\"display: none;\"><td><input id=\"addextra11\" onClick=\"showextra11();\" type=\"button\" value=\"Add Extras\" /></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>"; }
?>