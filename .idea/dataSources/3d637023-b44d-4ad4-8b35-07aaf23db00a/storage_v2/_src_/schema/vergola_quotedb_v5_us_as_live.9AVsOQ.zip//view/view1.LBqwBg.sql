create view view1 as
select `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`id`                  AS `id`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`contract_item_cf_id` AS `contract_item_cf_id`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`projectid`           AS `projectid`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`inventoryid`         AS `inventoryid`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`materialid`          AS `materialid`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`raw_cost`            AS `raw_cost`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`qty`                 AS `qty`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`length`              AS `length`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`supplierid`          AS `supplierid`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`process_po`          AS `process_po`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`section`             AS `section`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`is_reorder`          AS `is_reorder`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`length_feet`         AS `length_feet`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`length_inch`         AS `length_inch`,
       `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`.`length_fraction`     AS `length_fraction`
from `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_bom_meterial_vic`;

