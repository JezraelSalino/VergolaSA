create view v_contract_list as
select `c`.`sales_rep`      AS `Consultant`,
       `c`.`quoteid`        AS `ContractID`,
       `c`.`projectid`      AS `ProjectID`,
       `c`.`customer_name`  AS `Client Name`,
       `c`.`site_address`   AS `Site Address`,
       `c`.`framework`      AS `Framework`,
       `c`.`contractdate`   AS `ContractDate`,
       `c`.`framework_type` AS `Type`,
       `c`.`total_cost`     AS `Total Price`
from `vergola_quotedb_v5_us_as_live`.`ver_chronoforms_data_contract_list_vic` `c`;

